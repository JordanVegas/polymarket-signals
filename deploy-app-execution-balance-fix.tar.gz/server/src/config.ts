import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const parseNumber = (value: string | undefined, fallback: number): number => {
  if (!value) {
    return fallback;
  }

  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

const parseBoolean = (value: string | undefined, fallback: boolean): boolean => {
  if (!value) {
    return fallback;
  }

  const normalized = value.trim().toLowerCase();
  if (["1", "true", "yes", "on"].includes(normalized)) {
    return true;
  }

  if (["0", "false", "no", "off"].includes(normalized)) {
    return false;
  }

  return fallback;
};

const withDatabaseName = (mongoUri: string, databaseName: string): string => {
  try {
    const nextUri = new URL(mongoUri);
    nextUri.pathname = `/${databaseName}`;
    return nextUri.toString();
  } catch {
    return mongoUri;
  }
};

const defaultMongoUri = process.env.MONGO_URI || "mongodb://127.0.0.1:27017";
const configFilePath = fileURLToPath(import.meta.url);
const configDir = path.dirname(configFilePath);
const appRootDir = path.resolve(configDir, "..", "..");

const normalizeProxyUrl = (value: string): string => {
  const trimmed = value.trim();
  if (!trimmed) {
    return "";
  }

  if (/^(https?|socks5?):\/\//i.test(trimmed)) {
    return trimmed;
  }

  return `http://${trimmed}`;
};

const parseProxyUrls = (): string[] => {
  const inline = process.env.POLYMARKET_PROXY_URLS || process.env.API_PROXY_URLS || "";
  const filePath = process.env.POLYMARKET_PROXY_FILE || process.env.API_PROXY_FILE || "";

  const urls = new Set<string>();

  for (const entry of inline.split(/[\r\n,;]+/)) {
    const normalized = normalizeProxyUrl(entry);
    if (normalized) {
      urls.add(normalized);
    }
  }

  if (filePath.trim() && fs.existsSync(filePath.trim())) {
    const fileContents = fs.readFileSync(filePath.trim(), "utf8");
    for (const entry of fileContents.split(/[\r\n]+/)) {
      const normalized = normalizeProxyUrl(entry);
      if (normalized) {
        urls.add(normalized);
      }
    }
  }

  const single = normalizeProxyUrl(process.env.POLYMARKET_PROXY_URL || process.env.API_PROXY_URL || "");
  if (single) {
    urls.add(single);
  }

  return Array.from(urls);
};

const proxyEnabled = parseBoolean(
  process.env.POLYMARKET_PROXY_ENABLED ?? process.env.API_PROXY_ENABLED,
  true,
);

export const config = {
  port: parseNumber(process.env.PORT, 3001),
  marketIntelligencePort: parseNumber(process.env.MARKET_INTELLIGENCE_PORT, 3002),
  mongoUri: defaultMongoUri,
  mongoDbName: process.env.MONGO_DB_NAME || "polymarket_signals",
  mongoSignalsCollection: process.env.MONGO_SIGNALS_COLLECTION || "signals",
  authMongoUri: process.env.AUTH_MONGO_URI || withDatabaseName(defaultMongoUri, "authentication"),
  webSessionSecret: process.env.WEB_SESSION_SECRET || "change-me",
  tradingEncryptionSecret:
    process.env.TRADING_ENCRYPTION_SECRET || process.env.WEB_SESSION_SECRET || "change-me",
  webSessionCookieName: process.env.WEB_SESSION_COOKIE_NAME || "tuf_session",
  webCookieDomain: process.env.WEB_COOKIE_DOMAIN || "",
  minSignalClusterUsd: parseNumber(process.env.MIN_SIGNAL_CLUSTER_USD, 1_000),
  minWsTradeFetchUsd: parseNumber(process.env.MIN_WS_TRADE_FETCH_USD, 10),
  tradeWindowMs: parseNumber(process.env.TRADE_WINDOW_MS, 60_000),
  marketRefreshMs: parseNumber(process.env.MARKET_REFRESH_MS, 10 * 60_000),
  tradePollMs: parseNumber(process.env.TRADE_POLL_MS, 2_500),
  trackedTraderPollConcurrency: parseNumber(process.env.TRACKED_TRADER_POLL_CONCURRENCY, 3),
  apiProxyUrls: proxyEnabled ? parseProxyUrls() : [],
  recentCatchupLookbackMinutes: parseNumber(process.env.RECENT_CATCHUP_LOOKBACK_MINUTES, 30),
  recentCatchupMaxOffset: parseNumber(process.env.RECENT_CATCHUP_MAX_OFFSET, 3_000),
  historicalFetchEnabled: parseBoolean(process.env.HISTORICAL_FETCH_ENABLED, false),
  startupHistoricalBackfillEnabled: parseBoolean(
    process.env.STARTUP_HISTORICAL_BACKFILL_ENABLED,
    false,
  ),
  marketHistoryCatchupEnabled: parseBoolean(
    process.env.MARKET_HISTORY_CATCHUP_ENABLED,
    false,
  ),
  traderHistoryCatchupEnabled: parseBoolean(
    process.env.TRADER_HISTORY_CATCHUP_ENABLED,
    false,
  ),
  historicalBackfillLimit: parseNumber(process.env.HISTORICAL_BACKFILL_LIMIT, 2_000),
  historicalBackfillLookbackHours: parseNumber(
    process.env.HISTORICAL_BACKFILL_LOOKBACK_HOURS,
    168,
  ),
  liveExecutionErrorLogPath:
    process.env.LIVE_EXECUTION_ERROR_LOG_PATH
      ? path.resolve(appRootDir, process.env.LIVE_EXECUTION_ERROR_LOG_PATH)
      : path.resolve(appRootDir, "logs", "live-execution-errors.log"),
  appExecutionActionLogPath:
    process.env.APP_EXECUTION_ACTION_LOG_PATH
      ? path.resolve(appRootDir, process.env.APP_EXECUTION_ACTION_LOG_PATH)
      : path.resolve(appRootDir, "logs", "app-execution-actions.log"),
};
